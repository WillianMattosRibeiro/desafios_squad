import os
import requests
from datetime import datetime
from zipfile import ZipFile


"""
Função para baixar dados da mega e extrair
"""
def get_data_loteria (url: str, path: str, files_path: str, zip_path: str) -> None:
    try:
        # Baixa o arquivo do site da mega
        my_file= requests.get(url, allow_redirects=True)
        with open(zip_path, 'wb') as f:
            f.write(my_file.content)
        #Confere se já existe a pasta com a data atual, se não cria uma nova
        if not os.path.isdir(files_path):
            os.mkdir(files_path)
    
        # Extrai os arquivos do zip
        with ZipFile(zip_path, 'r') as zipObj:
            zipObj.extractall(path=files_path, members=None, pwd=None)
        # Remove o zip 
        os.remove(zip_path)
        
    except Exception as e:
            print(e)


"""
Parâmetros e executa a função get_data_loteria  
"""
def main():
    #Constantes
    url = "http://www1.caixa.gov.br/loterias/_arquivos/loterias/D_mgsasc.zip"
    path = "data"
    zip_path ="data\\D_mgsasc.zip"

    #Variáveis
    now = datetime.now()
    date_today = now.strftime("%Y-%m-%d")
    files_path= os.path.join(path, date_today)

    # Chama função
    get_data_loteria(url, path, files_path,zip_path)


# Executar main
if __name__ == '__main__':
    main()